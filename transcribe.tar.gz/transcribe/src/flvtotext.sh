flvdir=$1
mp3dir=$2
inputs3bucket=$3
outputs3bucket=$4
jsondir=$5
textdir=$6
waittime=$7

echo "######Converting flv files from input flv folder to mp3 and storing in output mp3 folder#####"
for f in $flvdir/*
   do
   echo "###converting" $f "to mp3###"
   file="$(basename "$f")"
   ffmpeg -i $f -q:a 5 $mp3dir${file%.flv}.mp3 
done

echo "######copying mp3 files to input s3 bucket####"
aws s3 cp $mp3dir $inputs3bucket --recursive

echo "#####waiting for 30 seconds####"
sleep 30

echo "####Converting files recursively to text###"
for file in $(aws s3 ls $inputs3bucket|cut -d" " -f 7); do
   echo "*****converting" $file "to text******"
   aws transcribe start-transcription-job --language-code "en-US"  --media-format "mp3" --transcription-job-name ${file%.mp3} --media "{\"MediaFileUri\":\"$inputs3bucket/$file\"}" --output-bucket-name $outputs3bucket
done

echo "###Waiting for" $waittime "seconds for transcribe job to complete###"
sleep $waittime

echo "####Copy output json files from outputs3bucket to local directory#####"
aws s3 cp "s3://"$outputs3bucket $jsondir --recursive

echo "###Waiting for 10 seconds###"
sleep 10

echo "####Parsing output json data to text###"
for f in $jsondir/*
   do
   echo "****Parsing" $f "to text***"
   file="$(basename "$f")"
   cat $f | jq ".results.transcripts[0].transcript" --raw-output >> $textdir${file%.json}.txt
done
